# 简介
------------------
1. ## 开发过程
+ vue init webpack app
+ npm i
[重置样式和响应式布局（rem+font-size方案）]:#
+ npm i reset.css lib-flexible --save-dev  //重置样式和响应式布局（rem+font-size方案）
+ npm i github-markdown-css --save  //支持github编辑的文章,使用时要给包裹元素加上类名markdown-body
+ npm install sass-loader --save-dev //使用scss编辑css
+ npm install axios --save //引入axios,用于http请求,
+ npm install zepto --save //引入zepto,用于DOM操作
+ npm install jsonp --save //引入jsonp,用于发送跨域请求

